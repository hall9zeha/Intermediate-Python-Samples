#módulo de saludo
def despedida():
	print("adios terricolas desde submódulo adios")

class despedidas:
	def __init__(self):
		print("despidiéndome desde la clase despedidas")