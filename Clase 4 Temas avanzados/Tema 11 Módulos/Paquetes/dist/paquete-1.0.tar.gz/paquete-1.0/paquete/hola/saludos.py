#módulo de saludo
def saludar():
	print("saludos terricolas desde módulo saludos")

class saludos:
	def __init__(self):
		print("saludando desde la clase saludos")