from setuptools import setup

setup(
name="paquete",
version="1.0",
description="Paquete de ejemplo",
author="Barry Zeha",
author_email="barry@gmail.com",
url="https://barry.info",
scripts=[],
packages=["paquete","paquete.adios","paquete.hola"]

	)